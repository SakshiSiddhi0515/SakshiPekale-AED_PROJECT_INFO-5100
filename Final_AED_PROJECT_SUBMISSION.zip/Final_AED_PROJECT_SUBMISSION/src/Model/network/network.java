/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.network;

import java.util.ArrayList;
import Model.enterprise.EnterDirectory;

/**
 *
 * @author sakshipekale
 */
public class network {
    private String country;

    private String state;

    private String city;
    
    private String name;

    private EnterDirectory enterpriseDirectory;
    

    public network() {
        enterpriseDirectory = new EnterDirectory();
    }

    public EnterDirectory getEnterpriseDirectory() {
        return enterpriseDirectory;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return this.city;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    
    public ArrayList<Integer> getZipCodesInRange(String city)
    {
        ArrayList<Integer> zipCodeList = new ArrayList<>();
        zipCodeList.add(01245);
        zipCodeList.add(02135);
        
        return zipCodeList;
    }
}
